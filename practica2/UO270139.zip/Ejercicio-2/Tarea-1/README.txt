Instrucciones de uso:
	Ejecutar con Python 3.9 (Click derecho, Abrir Con, Python 3.9)
	Los nombres de los archivos deben de ser todos absolutos (C:\Users\Usuario\Desktop\SEW\LAB\practica2\Ejercicio-2\Tarea-2\rutas.xml)