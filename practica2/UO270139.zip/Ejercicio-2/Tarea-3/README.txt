Instrucciones de uso:
	Ejecutar con Python 3.9 (Click derecho, Abrir Con, Python 3.9)
	Los nombres de los archivos deben de ser todos absolutos (C:\Users\Usuario\Desktop\SEW\LAB\practica2\Ejercicio-2\Tarea-3\rutas.xml)
	Cuando el programa te pregunte por el nombre de los archivos SVG, pon solo un nombre, no añadas ".svg" (C:\Users\Usuario\Desktop\SEW\LAB\practica2\Ejercicio-2\Tarea-3\ruta)